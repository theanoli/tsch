# MapKeeper-Specific Properties

## mapkeeper.host

Specifies the host MapKeeper server is running on (default: localhost). 

## mapkeeper.port

Specifies the port MapKeeper server is listening to (default: 9090). 
